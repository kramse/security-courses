package org.apache.tomcat.startup;

import java.net.*;
import java.io.*;

import java.util.*;

/**
 * 
 * @author Costin Manolache
 */
public class Property { 

    public Property() {
    }

    // -------------------- 

    public void setName(String n ) {
    }

    public void setValue( String v ) {

    }
}

